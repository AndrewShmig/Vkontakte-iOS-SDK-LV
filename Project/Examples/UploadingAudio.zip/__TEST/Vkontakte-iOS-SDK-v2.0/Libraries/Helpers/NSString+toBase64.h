//
//  NSString+toBase64.h
//  TwitterCommunicator2
//
//  Created by digipeople on 06.12.12.
//  Copyright (c) 2012 digipeople. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (toBase64)

-(NSString *)toBase64;

@end
