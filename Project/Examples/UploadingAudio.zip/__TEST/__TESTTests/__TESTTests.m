//
//  __TESTTests.m
//  __TESTTests
//
//  Created by AndrewShmig on 7/17/13.
//  Copyright (c) 2013 AndrewShmig. All rights reserved.
//

#import "__TESTTests.h"

@implementation __TESTTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in __TESTTests");
}

@end
