//
//  __TESTTests.h
//  __TESTTests
//
//  Created by AndrewShmig on 7/17/13.
//  Copyright (c) 2013 AndrewShmig. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface __TESTTests : SenTestCase

@end
