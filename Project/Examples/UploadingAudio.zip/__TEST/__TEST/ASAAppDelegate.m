//
//  ASAAppDelegate.m
//  __TEST
//
//  Created by AndrewShmig on 7/17/13.
//  Copyright (c) 2013 AndrewShmig. All rights reserved.
//

#import "ASAAppDelegate.h"
#import "ASAViewController.h"
#import "VKUser.h"


@implementation ASAAppDelegate

- (BOOL)application:(UIApplication *)application
        didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.viewController = [[ASAViewController alloc] initWithNibName:@"ASAViewController" bundle:nil];
    self.window.rootViewController = self.viewController;
    [self.window makeKeyAndVisible];

//    CODE BEGIN
    [[VKConnector sharedInstance]
                  setDelegate:self];
    [[VKConnector sharedInstance] startWithAppID:@"3541027"
                                      permissons:@[@"audio"]];
//    CODE END


    return YES;
}

#pragma mark - VKConnectorDelegate

- (void)        VKConnector:(VKConnector *)connector
accessTokenRenewalSucceeded:(VKAccessToken *)accessToken
{
//    предварительная настройка
    [VKUser currentUser].startAllRequestsImmediately = NO;
    [VKUser currentUser].delegate = self;

//    получение УРЛа для загрузки аудио
    VKRequest *firstStep = [[VKUser currentUser]
                                    audioGetUploadServer:@{}];
    firstStep.signature = @"firstStep";

//    не надо кэшировать УРЛ загрузки, ибо каждый раз нам необходим новый
    firstStep.cacheLiveTime = VKCachedDataLiveTimeNever;

//    начинаем выполнение запроса
    [firstStep start];
}

#pragma mark - VKRequestDelegate

- (void)VKRequest:(VKRequest *)request
         response:(id)response
{
    if([request.signature isEqualToString:@"firstStep"]){
//        получили УРЛ для загрузки аудио
        NSString* uploadURL = response[@"response"][@"upload_url"];

//        создаем тело запрос - содержимое будет содержать аудио файл
        NSString *audioPath = [[NSBundle mainBundle]
                                         pathForResource:@"Crashdiet - Armagedon"
                                                  ofType:@"mp3"];

//        создаем запрос на загрузку аудио
        VKRequest *secondStep = [VKRequest requestHTTPMethod:@"POST"
                                                         URL:[NSURL URLWithString:uploadURL]
                                                     headers:@{}
                                                        body:nil
                                                    delegate:self];
        [secondStep appendAudioFile:[NSData dataWithContentsOfFile:audioPath]
                               name:@"Crashdiet - Armagedon.mp3"
                              field:@"file"];
        secondStep.signature = @"secondStep";
        secondStep.cacheLiveTime = VKCachedDataLiveTimeNever;

//        запускаем
        [secondStep start];
    }

//    а теперь мы должны сохранить аудио
    if([request.signature isEqualToString:@"secondStep"]){
        VKRequest *thirdStep = [[VKUser currentUser]
                                        audioSave:@{
                                                @"server": response[@"server"],
                                                @"hash": response[@"hash"],
                                                @"audio": response[@"audio"]
                                        }];

        thirdStep.signature = @"thirdStep";
        thirdStep.delegate = self;

//        нет надобности кэшировать такие данные
        thirdStep.cacheLiveTime = VKCachedDataLiveTimeNever;

        [thirdStep start];
    }

    if ([request.signature isEqualToString:@"thirdStep"]) {
        NSLog(@"Audio file was uploaded successful!");
    }
}

- (void)VKRequest:(VKRequest *)request
       totalBytes:(NSUInteger)totalBytes
    uploadedBytes:(NSUInteger)uploadedBytes
{
    NSLog(@"%zu [%zu]", (unsigned long)totalBytes, (unsigned long)uploadedBytes);
}

@end