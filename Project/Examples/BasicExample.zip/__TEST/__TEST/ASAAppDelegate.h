//
//  ASAAppDelegate.h
//  __TEST
//
//  Created by AndrewShmig on 7/14/13.
//  Copyright (c) 2013 AndrewShmig. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VKConnector.h"

@class ASAViewController;

@interface ASAAppDelegate : UIResponder <UIApplicationDelegate, VKConnectorDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ASAViewController *viewController;

@end