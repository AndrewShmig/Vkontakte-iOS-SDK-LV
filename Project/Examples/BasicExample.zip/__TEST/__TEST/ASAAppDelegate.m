//
//  ASAAppDelegate.m
//  __TEST
//
//  Created by AndrewShmig on 7/14/13.
//  Copyright (c) 2013 AndrewShmig. All rights reserved.
//

#import "ASAAppDelegate.h"

#import "ASAViewController.h"
#import "VKAccessToken.h"

@implementation ASAAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];

    // Override point for customization after application launch.
    self.viewController = [[ASAViewController alloc] initWithNibName:@"ASAViewController" bundle:nil];

    self.viewController.view = [[UIView alloc]
                                        initWithFrame:[[UIScreen mainScreen]
                                                                 bounds]];
    [self.viewController.view setBackgroundColor:[UIColor whiteColor]];

    CGRect btnFrame = CGRectMake(60, 100, 150, 60);
    UIButton *authorize = [[UIButton alloc] initWithFrame:btnFrame];
    [authorize setBackgroundColor:[UIColor grayColor]];
    [authorize setTitle:@"Authorize app"
               forState:UIControlStateNormal];
    [authorize addTarget:self
                  action:@selector(buttonTapped)
        forControlEvents:UIControlEventTouchUpInside];

    [self.viewController.view addSubview:authorize];

    self.window.rootViewController = self.viewController;
    [self.window makeKeyAndVisible];
    return YES;
}

- (void)buttonTapped
{
    [[VKConnector sharedInstance] setDelegate:self];
    [[VKConnector sharedInstance] startWithAppID:@"3541027"
                                      permissons:@[@"photos", @"wall", @"friends"]];
}

- (void)VKConnector:(VKConnector *)connector accessTokenRenewalSucceeded:(VKAccessToken *)accessToken
{
    NSLog(@"New token: %@", accessToken);
}

- (void)VKConnector:(VKConnector *)connector accessTokenRenewalFailed:(VKAccessToken *)accessToken
{
    NSLog(@"User denied app authorization.");
}

@end