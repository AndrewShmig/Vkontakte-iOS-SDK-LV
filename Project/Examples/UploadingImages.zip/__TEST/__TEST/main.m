//
//  main.m
//  __TEST
//
//  Created by AndrewShmig on 7/18/13.
//  Copyright (c) 2013 AndrewShmig. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "ASAAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([ASAAppDelegate class]));
    }

}