//
//  ASAViewController.m
//  __TEST
//
//  Created by AndrewShmig on 7/18/13.
//  Copyright (c) 2013 AndrewShmig. All rights reserved.
//

#import "ASAViewController.h"

@interface ASAViewController ()

@end

@implementation ASAViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end