//
//  ASAAppDelegate.m
//  __TEST
//
//  Created by AndrewShmig on 7/18/13.
//  Copyright (c) 2013 AndrewShmig. All rights reserved.
//

#import "ASAAppDelegate.h"

#import "ASAViewController.h"
#import "VKUser.h"

@implementation ASAAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    self.viewController = [[ASAViewController alloc] initWithNibName:@"ASAViewController" bundle:nil];
    self.window.rootViewController = self.viewController;
    [self.window makeKeyAndVisible];

//    CODE BEGIN
    [[VKConnector sharedInstance]
                  setDelegate:self];
    [[VKConnector sharedInstance] startWithAppID:@"3541027"
                                      permissons:@[@"photos"]];
//    CODE END

    return YES;
}

#pragma mark - VKConnectorDelegate

- (void)        VKConnector:(VKConnector *)connector
accessTokenRenewalSucceeded:(VKAccessToken *)accessToken
{
    [VKUser currentUser].delegate = self;
    [VKUser currentUser].startAllRequestsImmediately = NO;

//    получение сервера загрузки изображений
    VKRequest *firstStep = [[VKUser currentUser]
                                    photosGetUploadServer:@{
                                            @"album_id" : @(167233642)
                                    }];
    firstStep.signature = @"firstStep";
    firstStep.cacheLiveTime = VKCachedDataLiveTimeNever;

    [firstStep start];
}

#pragma mark - VKRequestDelegate

- (void)VKRequest:(VKRequest *)request response:(id)response
{
    if([request.signature isEqualToString:@"firstStep"]){
        NSString *uploadURL = response[@"response"][@"upload_url"];

//        теперь создадим запрос на отправку всех изображений
        VKRequest *secondStep = [VKRequest requestHTTPMethod:@"POST"
                                                         URL:[NSURL URLWithString:uploadURL]
                                                     headers:@{}
                                                        body:nil
                                                    delegate:self];
        secondStep.signature = @"secondStep";

//        добавляем все четыре файлов в тело запроса
        for(int i=1; i<=4; i++){
            NSString* name = [NSString stringWithFormat:@"%d.jpg", i];
            NSString* field = [NSString stringWithFormat:@"file%d", i];

            NSString *filePath = [[NSBundle mainBundle]
                                            pathForResource:[NSString stringWithFormat:@"%d",
                                                                                       i]
                                                     ofType:@"jpg"];

            NSData* imageData = [NSData dataWithContentsOfFile:filePath];

            [secondStep appendImageFile:imageData
                                   name:name
                                  field:field];
        }

        [secondStep start];
    }

    if([request.signature isEqualToString:@"secondStep"]){
        NSString* server = response[@"server"];
        NSString* photosList = response[@"photos_list"];
        NSString* aid = response[@"aid"];
        NSString* hash = response[@"hash"];

//        сохраняем загруженные фотографии
        VKRequest *thirdStep = [[VKUser currentUser]
                                        photosSave:@{
                                                @"server"      : server,
                                                @"photos_list" : photosList,
                                                @"album_id"    : aid,
                                                @"hash"        : hash
                                        }];
        thirdStep.signature = @"thirdStep";
        thirdStep.cacheLiveTime = VKCachedDataLiveTimeNever;

        [thirdStep start];
    }

    if([request.signature isEqualToString:@"thirdStep"]){
        NSLog(@"===> Images were uploaded! <===");
    }
}

- (void)VKRequest:(VKRequest *)request
       captchaSid:(NSString *)captchaSid
     captchaImage:(NSString *)captchaImage
{
    NSLog(@"Captcha needed!");
}

- (void)VKRequest:(VKRequest *)request responseErrorOccured:(id)error
{
    NSLog(@"response error: %@", error);
}

- (void)VKRequest:(VKRequest *)request parsingErrorOccured:(NSError *)error
{
    NSLog(@"parsing error: %@", error);
}

- (void)VKRequest:(VKRequest *)request connectionErrorOccured:(NSError *)error
{
    NSLog(@"connection error");
}

@end