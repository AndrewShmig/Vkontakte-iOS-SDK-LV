//
//  ASAAppDelegate.m
//  __TEST
//
//  Created by AndrewShmig on 7/15/13.
//  Copyright (c) 2013 AndrewShmig. All rights reserved.
//

#import "ASAAppDelegate.h"
#import "ASAViewController.h"
#import "VKUser.h"
#import "VKAccessToken.h"

@implementation ASAAppDelegate
{
    NSMutableArray *_tableData;
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.viewController = [[ASAViewController alloc] initWithNibName:@"ASAViewController" bundle:nil];
    self.window.rootViewController = self.viewController;

    CGRect frame = [[UIScreen mainScreen] bounds];
    _tableView = [[UITableView alloc]
                               initWithFrame:frame
                                       style:UITableViewStylePlain];
    [_tableView setDelegate:self];
    [_tableView setDataSource:self];
    [self.viewController.view addSubview:_tableView];

    _tableData = [[NSMutableArray alloc] init];

    [[VKConnector sharedInstance]
                  setDelegate:self];
    [[VKConnector sharedInstance] startWithAppID:@"3541027"
                                      permissons:@[@"friends"]];

    [self.window makeKeyAndVisible];
    return YES;
}

#pragma mark - VKConnectorDelegate

- (void)        VKConnector:(VKConnector *)connector
accessTokenRenewalSucceeded:(VKAccessToken *)accessToken
{
//   now we can make request
    [[VKUser currentUser] setDelegate:self];
    [[VKUser currentUser] friendsGet:@{
            @"uid"    : @([VKUser currentUser].accessToken.userID),
            @"fields" : @"first_name,last_name,photo,status"
    }];
}

#pragma mark - VKRequestDelegate

- (void)VKRequest:(VKRequest *)request
         response:(id)response
{
    _tableData = response[@"response"];

    [_tableView reloadData];
}

#pragma mark - UITableViewDelegate & DataSource

- (NSInteger)tableView:(UITableView *)tableView
  numberOfRowsInSection:(NSInteger)section
{
    return [_tableData count];
}

- (UITableViewCell *)tableView:(UITableView *)table
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString* cellID = @"friendID";

    UITableViewCell *cell = [table dequeueReusableCellWithIdentifier:cellID];

    if(nil == cell)
        cell = [[UITableViewCell alloc]
                initWithStyle:UITableViewCellStyleSubtitle
              reuseIdentifier:cellID];

//    setting default image while main photo is loading
    cell.imageView.image = [UIImage imageNamed:@"default.jpeg"];

    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
        NSString* imgPath = _tableData[(NSUInteger)indexPath.row][@"photo"];
        NSData* img = [NSData dataWithContentsOfURL:[NSURL URLWithString:imgPath]];

        dispatch_async(dispatch_get_main_queue(), ^{
            cell.imageView.image = [UIImage imageWithData:img];
        });
    });

    NSString* firstName = _tableData[(NSUInteger)indexPath.row][@"first_name"];
    NSString* lastName = _tableData[(NSUInteger)indexPath.row][@"last_name"];
    NSString* fullName = [NSString stringWithFormat:@"%@ %@", firstName, lastName];
    cell.textLabel.text = fullName;

    NSString* status = _tableData[(NSUInteger)indexPath.row][@"status"];
    cell.detailTextLabel.text = status;

    return cell;
}


@end