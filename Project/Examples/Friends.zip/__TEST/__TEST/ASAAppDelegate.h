//
//  ASAAppDelegate.h
//  __TEST
//
//  Created by AndrewShmig on 7/15/13.
//  Copyright (c) 2013 AndrewShmig. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VKConnector.h"
#import "VKRequest.h"

@class ASAViewController;

@interface ASAAppDelegate : UIResponder <UIApplicationDelegate,
        UITableViewDelegate, UITableViewDataSource, VKConnectorDelegate,
        VKRequestDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) ASAViewController *viewController;
@property (strong, nonatomic) UITableView *tableView;

@end